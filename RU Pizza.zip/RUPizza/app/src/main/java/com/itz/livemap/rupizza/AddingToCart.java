package com.itz.livemap.rupizza;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class AddingToCart extends AppCompatActivity {
    TextView name,description,price;
    ImageView imageView;
    int position;
    Button button;
    public static int a=0;
    public static ArrayList<Model> addList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adding_to_cart);
        addList = new ArrayList<>();

        name = findViewById(R.id.name);
        description= findViewById(R.id.description);
        price = findViewById(R.id.txt);
        imageView = findViewById(R.id.image);
        button = findViewById(R.id.cartEnd);
        Intent mIntent = getIntent();
        position = mIntent.getIntExtra("position", 0);
        if (position == 0){
            name.setText("Deluxe Pizza");
            imageView.setImageResource(R.drawable.deluxe_pizza);
            description.setText("You have Order one Deluxe Pizza and its will very tasty and delicious ");
            price.setText("$16");

        } else if (position ==1){
            name.setText("Pepperoni Pizza");
            imageView.setImageResource(R.drawable.pepperoni_pizza);
            description.setText("You have Order one Pepperoni Pizza and its will very tasty and delicious");
            price.setText("$18");

        }else  if (position ==2){
            name.setText("Meatzza Pizza");
            imageView.setImageResource(R.drawable.meatzza_pizza);
            description.setText("You have Ordered Meatzza Pizza from our menu and we are hoping you will like our service");
            price.setText("$14");

        } else  if (position ==3){
            name.setText("Seafood Pizza");
            imageView.setImageResource(R.drawable.seafood_pizza);
            description.setText("You have Ordered Seafood Pizza from our menu and we are hoping you will like our service");
            price.setText("$30");

        } else  if (position ==4){
            name.setText("Supreme Pizza");
            imageView.setImageResource(R.drawable.supreme_pizza);
            description.setText("You have Ordered Supreme Pizza from our menu and we are hoping you will like our service");
            price.setText("$20");

        }else  if (position ==5){
            name.setText("Cheese Pizza");
            imageView.setImageResource(R.drawable.cheese_pizza);
            description.setText("You have Ordered Cheese Pizza from our menu and we are hoping you will like our service");
            price.setText("$17");

        }else  if (position ==6){
            name.setText("BBQ Chicken Pizza");
            imageView.setImageResource(R.drawable.bbq_pizza);
            description.setText("You have Ordered BBQ Chicken Pizza from our menu and we are hoping you will like our service");
            price.setText("$15");

        }else  if (position ==7){
            name.setText("Buffalo Pizza");
            imageView.setImageResource(R.drawable.buffalo_pizza);
            description.setText("You have Ordered Buffalo Pizza from our menu and we are hoping you will like our service");
            price.setText("$10");

        }else  if (position ==8){
            name.setText("Hawaiian Pizza");
            imageView.setImageResource(R.drawable.hawaiian_pizza);
            description.setText("You have Ordered Hawaiian Pizza from our menu and we are hoping you will like our service");
            price.setText("$19");

        }else  if (position ==9){
            name.setText("Veggie Pizza");
            imageView.setImageResource(R.drawable.veggie_pizza);
            description.setText("You have Ordered Veggie Pizza from our menu and we are hoping you will like our service");
            price.setText("$25");

        }
        else {
            Toast.makeText(this, "You can't show any data", Toast.LENGTH_SHORT).show();
        }

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (position ==0){
                    showDialogue();
                    addList.add(new Model("Deluxe pizza","$16", R.drawable.deluxe_pizza));
                    Toast.makeText(AddingToCart.this, "Deluxe pizza"+" is added into Cart", Toast.LENGTH_SHORT).show();
//                    onBackPressed();
                }else if (position ==1){
                    showDialogue();
                    addList.add(new Model("Pepperoni pizza","$18", R.drawable.pepperoni_pizza));
                    Toast.makeText(AddingToCart.this, "Pepperoni pizza is added into Cart", Toast.LENGTH_SHORT).show();
//                    onBackPressed();

                }else if (position ==2){
                    showDialogue();
                    addList.add(new Model("Meatzza Pizza","$14", R.drawable.meatzza_pizza));
                    Toast.makeText(AddingToCart.this, "Meatzza Pizza is added into Cart", Toast.LENGTH_SHORT).show();
//                    onBackPressed();

                }else if (position ==3){
                    showDialogue();
                    addList.add(new Model("Seafood Pizza","$30", R.drawable.seafood_pizza));
                    Toast.makeText(AddingToCart.this, "Seafood Pizza is added into Cart", Toast.LENGTH_SHORT).show();
//                    onBackPressed();

                }else if (position ==4){
                    showDialogue();
                    addList.add(new Model("Supreme Pizza","$20", R.drawable.supreme_pizza));
                    Toast.makeText(AddingToCart.this, "Supreme Pizza is added into Cart", Toast.LENGTH_SHORT).show();
//                    onBackPressed();

                }else if (position ==5){
                    showDialogue();
                    addList.add(new Model("Cheese Pizza","$17", R.drawable.cheese_pizza));
                    Toast.makeText(AddingToCart.this, "Cheese Pizza is added into Cart", Toast.LENGTH_SHORT).show();
//                    onBackPressed();

                }else if (position ==6){
                    showDialogue();
                    addList.add(new Model("BBQ Chicken Pizza","$15", R.drawable.bbq_pizza));
                    Toast.makeText(AddingToCart.this, "BBQ Chicken Pizza is added into Cart", Toast.LENGTH_SHORT).show();
//                    onBackPressed();

                }else if (position ==7){
                    showDialogue();
                    addList.add(new Model("Buffalo Pizza","$10", R.drawable.buffalo_pizza));
                    Toast.makeText(AddingToCart.this, "Buffalo Pizza is added into Cart", Toast.LENGTH_SHORT).show();
//                    onBackPressed();

                }else if (position ==8){
                    showDialogue();
                    addList.add(new Model("Hawaiian Pizza","$19", R.drawable.hawaiian_pizza));
                    Toast.makeText(AddingToCart.this, "Hawaiian Pizza is added into Cart", Toast.LENGTH_SHORT).show();
//                    onBackPressed();

                }else if (position ==9){
                    showDialogue();
                    addList.add(new Model("Veggie Pizza","$25", R.drawable.veggie_pizza));

                    Toast.makeText(AddingToCart.this, "Veggie Pizza is added into Cart", Toast.LENGTH_SHORT).show();
//                    onBackPressed();

                }

            }
        });

    }
    public void showDialogue(){
        AlertDialog.Builder builder = new AlertDialog.Builder(AddingToCart.this);
// Add the buttons.
        builder.setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                Toast.makeText(AddingToCart.this, "Thank you for your Order", Toast.LENGTH_SHORT).show();
            }
        });
        builder.setMessage(R.string.order);
        builder.setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                // User cancels the dialog.
            }
        });
// Set other dialog properties.

// Create the AlertDialog.
        AlertDialog dialog = builder.create();
        dialog.show();

    }
}