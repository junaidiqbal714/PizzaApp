package com.itz.livemap.rupizza;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class pizzaAdapter extends RecyclerView.Adapter<pizzaAdapter.ViewHolder> {
    ArrayList<Model> pizzaList;
    Context context;

    public pizzaAdapter(ArrayList<Model> pizzaList, Context context) {
        this.pizzaList = pizzaList;
        this.context = context;
    }

    @NonNull
    @Override
    public pizzaAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_view, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull pizzaAdapter.ViewHolder holder, @SuppressLint("RecyclerView") int position) {
        holder.name.setText(pizzaList.get(position).getName());
        holder.price.setText(pizzaList.get(position).getPrice());
        holder.pizza.setImageResource(pizzaList.get(position).getImage());
        holder.layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, PizzaSize.class);
                intent.putExtra("position",position);
                context.startActivity(intent);

            }
        });

    }

    @Override
    public int getItemCount() {
        return pizzaList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView name, price;
        ImageView pizza;
        ConstraintLayout layout;
        public ViewHolder(@NonNull View itemView)
        {
            super(itemView);
            name = itemView.findViewById(R.id.pizzaName);
            price = itemView.findViewById(R.id.pizzaPrice);
            pizza = itemView.findViewById(R.id.pizzaImage);
            layout = itemView.findViewById(R.id.itemView);
        }
    }
    public void filterList(ArrayList<Model> filteredList) {
        pizzaList = filteredList;
        notifyDataSetChanged();
    }
}
