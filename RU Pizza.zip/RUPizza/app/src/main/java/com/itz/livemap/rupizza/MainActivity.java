package com.itz.livemap.rupizza;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.widget.EditText;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    RecyclerView recyclerView;
    pizzaAdapter adapter;
    ArrayList<Model> arrayList;
    EditText search;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // initialization of objects
        recyclerView = findViewById(R.id.recyclerView);
        search = findViewById(R.id.search);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this,RecyclerView.VERTICAL, false);
        recyclerView.setLayoutManager(layoutManager);
        arrayList= new ArrayList<>();
        arrayList.add(new Model("Deluxe Pizza","$16", R.drawable.deluxe_pizza));
        arrayList.add(new Model("Pepperoni Pizza ","$18", R.drawable.pepperoni_pizza));
        arrayList.add(new Model("Meatzza Pizza","$14", R.drawable.meatzza_pizza));
        arrayList.add(new Model("Seafood Pizza","$30", R.drawable.seafood_pizza));
        arrayList.add(new Model("Supreme Pizza","$20", R.drawable.supreme_pizza));
        arrayList.add(new Model("Cheese Pizza","$17", R.drawable.cheese_pizza));
        arrayList.add(new Model("BBQ Chicken Pizza","$15", R.drawable.bbq_pizza));
        arrayList.add(new Model("Buffalo Pizza","$10", R.drawable.buffalo_pizza));
        arrayList.add(new Model("Hawaiian Pizza","$19", R.drawable.hawaiian_pizza));
        arrayList.add(new Model("Veggie Pizza","$25", R.drawable.veggie_pizza));
        adapter = new pizzaAdapter(arrayList,this);
        Log.d("TAG", "onCreateView: "+arrayList.size());
        recyclerView.setAdapter(adapter);


        // search work by edittext
        search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                filter(editable.toString());

            }
        });
    }
    private void filter(String text) {
        ArrayList<Model> filteredList = new ArrayList<>();

        for (Model item : arrayList) {
            if (item.getName().toLowerCase().contains(text.toLowerCase())) {
                filteredList.add(item);
            }
            adapter.filterList(filteredList); }


    }
}